# 📚 Student Management System

A beginner-friendly Java console project using OOP concepts and file handling.

## 🚀 Features

- Add Student
- Remove Student
- Update Student
- Search Student
- Display Students
- Save Data in File

## 🛠 Technologies Used

- Java
- OOP
- ArrayList
- CRUD Operations
- File Handling

## ▶️ How to Run

1. Open project in VS Code or IntelliJ
2. Compile all files
3. Run Main.java

## 👨‍💻 Author

Bani Vig
